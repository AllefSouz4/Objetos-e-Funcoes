var produto = {
    nome: 'Memoria Ram',
    quantidade: 100,
    preço: 198,

}

function calculartotal (quant1, prec1) {
    total = quant1 * prec1
    console.log(total)
}
calculartotal(produto.quantidade, produto.preço)