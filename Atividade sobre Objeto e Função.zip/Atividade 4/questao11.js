var pessoa = {
    nome: 'Allef',
    idade: 22,
    cidade: 'Salvador'}

    console.log(pessoa)