var carro = {
    marca: 'mitsubishi',
    modelo: 'lancer evolution',
    ano: 2012,

    colocarMarca() {
        console.log(carro)
    }
}
carro.colocarMarca()