var x = 12
var y = 15

function soma(numero1, numero2) {
    return (numero1 + numero2)
}
var total = soma(x, y)
console.log(total)