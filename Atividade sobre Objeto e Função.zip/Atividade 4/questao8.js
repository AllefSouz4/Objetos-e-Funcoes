var palavra = 'ola tudo bem'

function contarPalavras(texto){
     let Npalavras= texto.split(' ')

    return (Npalavras)
}
console.log(contarPalavras(palavra))