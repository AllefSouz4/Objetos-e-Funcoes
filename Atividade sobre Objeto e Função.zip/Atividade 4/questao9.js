var valormini = 1
var valormaxim = 10





function gerarNumeroAleatorio(a, b ){

    var aleatorioint = Math.floor(Math.random(a, b)* 10)
 console.log(aleatorioint)
 return
}
gerarNumeroAleatorio(valormini, valormaxim)