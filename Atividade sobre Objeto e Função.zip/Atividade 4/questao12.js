var pessoa = {
    nome: 'Allef',
    idade: 22,
    cidade: 'Salvador'
}


function mostrarInfo(n1) {
 return (n1)
}
console.log(mostrarInfo(pessoa))