var produto = {
    nome: 'Memoria Ram',
    quantidade: 100,
    preço: 198,

}
console.log(produto)